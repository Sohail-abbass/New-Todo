// userSlice.js
import { createSlice } from "@reduxjs/toolkit";

// Initial state
const initialState = []; // Empty array to hold user data

// Creating a slice for users
const userSlice = createSlice({
  name: "users", // Name for the slice
  initialState:initialState,
  reducers: {
    addTodo: (state, action) => {
      state.push(action.payload); // Add a new user
    },
    removeTodo: (state, action) => {
      return state.filter((user) => user.id !== action.payload); // Remove user by ID
    },
  
    updateTodo: (state, action) => {
      const { id, name, email } = action.payload;
      const existingUser = state.find((user) => user.id === id); // Ensure ID types match
      if (existingUser) {
          existingUser.name = name;
          existingUser.email = email;
      }
  },
  

  

    finishAll: () => {
      return []; // Clear all users
    },
  },
});

// Exporting actions to be used in components
export const { addTodo, removeTodo, updateTodo, finishAll } = userSlice.actions;

// Export the reducer to be used in store
export default userSlice.reducer;
