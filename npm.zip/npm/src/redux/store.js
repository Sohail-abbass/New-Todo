// store.js
import { configureStore } from '@reduxjs/toolkit';
import userSlice from './userSlice'; // Import the reducer from userSlice.js

// Creating the Redux store
const store = configureStore({
  reducer: {
    users: userSlice, // Register the user slice in the Redux store
  },
});

export default store; // Export the store to use in the app
