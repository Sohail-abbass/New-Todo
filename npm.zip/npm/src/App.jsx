import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap styles
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./components/HomePage";
import Create from "./components/Create";
import Update from "./components/Update";
import Myerror from "./components/Myerror";

function App() {
  return (
    <>
      
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/create" element={<Create />} />
          <Route path="/update/:id" element={<Update />} />
          <Route path="*" element={<Myerror />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
