import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { updateTodo } from "../redux/userSlice";

const Update = () => {
  const { id } = useParams();
  const users = useSelector((state) => state.users);
  const existingUser = users.find((f) => f.id === parseInt(id, 10));

  const [uname, setName] = useState("");
  const [uemail, setEmail] = useState("");

  const dispatch = useDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    if (existingUser) {
      setName(existingUser.name);
      setEmail(existingUser.email);
    }
  }, [existingUser]);

  if (!existingUser) {
    return <div>User not found</div>;
  }

  const handlesubmit = (event) => {
    event.preventDefault();
    const payload = {
      id: parseInt(id, 10),
      name: uname,
      email: uemail,
    };
    dispatch(updateTodo(payload));
    navigate("/");
  };

  return (
    <div className="d-flex w-100 vh-100 bg-light justify-content-center align-items-center">
            <div className="w-50 border bg-secondary text-white p-5">
        {/* <h3 className="mb-4 text-center">Update User</h3> */}
        <form onSubmit={handlesubmit}>
          <div className="mb-3">
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              name="name"
              className="form-control"
              placeholder="Enter your name"
              value={uname}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              name="email"
              className="form-control"
              placeholder="Enter your email"
              value={uemail}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <button className="btn btn-info w-100">Update</button>
        </form>
      </div>
    </div>
  );
};

export default Update;
