import { Link } from "react-router-dom";
import { removeTodo, finishAll } from "../redux/userSlice";
import { useDispatch, useSelector } from "react-redux";

function HomePage() {
  const dispatch = useDispatch();
  const users = useSelector((state) => state.users);

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      dispatch(removeTodo(id));
    }
  };

  const removeAll = () => {
    if (window.confirm("Are you sure you want to delete all users?")) {
      dispatch(finishAll());
    }
  };

  return (
  
    <div className="container">
        <h2>CRUD App with Redux</h2>
      
          <Link to="/create" className="btn btn-success">
            Create +
          </Link>
    
        {users.length > 0 ? (
          <table className="table table-bordered">
            <thead className="table-dark">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>
                    <Link
                      to={`/update/${user.id}`}
                      className="btn btn-sm btn-primary me-2"
                    >
                      Edit
                    </Link>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDelete(user.id)}
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="alert alert-info text-center">No users found</div>
        )}
        {users.length > 0 && (
          <button className="btn btn-md btn-danger mt-3 w-100" onClick={removeAll}>
            Delete All
          </button>
        )}
      
        </div>
  );
}

export default HomePage;
