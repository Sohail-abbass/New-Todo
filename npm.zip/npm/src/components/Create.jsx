import { useState } from "react";
import { addTodo } from "../redux/userSlice";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

function Create() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const users = useSelector((state) => state.users);

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!name || !email) {
      alert("Please fill in all fields");
      return;
    }

    
 // Check if email already exists
 const emailExists = users.some(user => user.email === email);
 if (emailExists) {
   alert("This email is already taken. Please use a unique email.");
   return;
 }

 
    const newId = users.length > 0 ? users[users.length - 1].id + 1 : 1;

    dispatch(addTodo({ id: newId, name, email }));
    navigate("/");
  };

  return (
    <div className="d-flex w-100 vh-100 bg-light justify-content-center align-items-center">
            <div className="w-50 border bg-secondary text-white p-5">
        <h3 className="mb-4 text-center">Add New User</h3>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">
              Name:
            </label>
            <input
              type="text"
              name="name"
              className="form-control"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">
              Email:
            </label>
            <input
              type="email"
              name="email"
              className="form-control"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <button className="btn btn-info w-100">Submit</button>
        </form>
      </div>
    </div>
  );
}

export default Create;
