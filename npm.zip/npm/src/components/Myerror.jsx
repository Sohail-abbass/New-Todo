import { Link } from "react-router-dom";

function Myerror() {
  return (
    <div className="d-flex flex-column justify-content-center align-items-center vh-100 bg-light">
      <h1 className="display-4 text-danger">404</h1>
      <h2 className="mb-4">Oops! Page Not Found</h2>
      <p className="text-muted mb-4">
        The page you are looking for does not exist or an error occurred.
      </p>
      <Link to="/" className="btn btn-primary">
        Go Back to Home
      </Link>
    </div>
  );
}

export default Myerror;
